# EASY MARKET Android starter

This is a starter Android WebView demo app branded as EASY MARKET.

## Build APK with GitHub Actions
1. Extract this ZIP.
2. Upload the CONTENTS of this ZIP to the root of your GitHub repository, keeping folders such as `app` and `.github`.
3. Commit the files to the `main` branch.
4. Open the repository's Actions tab and run `Build EASY MARKET APK` (or wait for the push-triggered run).
5. When the run succeeds, download the `EasyMarket-APK` artifact and extract the APK from the downloaded ZIP.

## Important limitations
This is a demo only. It does not include a real admin login, product database, order backend, or automatic bKash/Nagad transaction verification. A transaction ID typed into the demo page is not verified or saved to a server. Real payment verification requires a backend and an approved payment integration.
